package JavaBasic;

public abstract class Phone {

}
