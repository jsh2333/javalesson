package JavaEx;

public class MyMath {
	long a, b;
	
	long add() {
		return a+b;
	}
	long sub() {
		return a-b;
		
	}
	long mult() {
		return a*b;
	}
	double div() {
		return a/b;
	}
	
	static long add(long a, long b) {
		return a+b;
	}
	static long sub(long a, long b) {
		return a-b;
	}
	static long mult(long a, long b) {
		return a*b;
	}
	static long div(long a, long b) {
		return a/b;
	}
}
